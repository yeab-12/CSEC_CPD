<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ASTU Student Management</title>
    <style>
        :root {
            --primary: #3498db;
            --primary-dark: #2980b9;
            --secondary: #2c3e50;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --gradient: linear-gradient(135deg, #3498db, #2c3e50);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            --radius: 12px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 40px 20px;
            color: var(--dark);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
            position: relative;
        }
        
        .university-badge {
            display: inline-block;
            background: var(--gradient);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
            letter-spacing: 1px;
            margin-bottom: 15px;
            box-shadow: var(--shadow);
        }
        
        h2 {
            font-size: 42px;
            font-weight: 800;
            color: var(--secondary);
            margin-bottom: 10px;
            background: linear-gradient(to right, #3498db, #2c3e50);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
            display: inline-block;
        }
        
        h2:after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: var(--gradient);
            border-radius: 2px;
        }
        
        .subtitle {
            color: var(--gray);
            font-size: 18px;
            margin-top: 25px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .card {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 35px 30px;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-top: 6px solid var(--primary);
        }
        
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .card.delete-card {
            border-top-color: var(--danger);
        }
        
        .card-icon {
            width: 70px;
            height: 70px;
            background: var(--gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 25px;
            color: white;
            font-size: 30px;
            box-shadow: 0 8px 20px rgba(52, 152, 219, 0.3);
        }
        
        .delete-card .card-icon {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
        }
        
        .card h3 {
            font-size: 24px;
            font-weight: 700;
            color: var(--secondary);
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--secondary);
            font-size: 15px;
            padding-left: 5px;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 18px;
        }
        
        input[type="number"],
        input[type="text"] {
            width: 100%;
            padding: 16px 16px 16px 50px;
            border: 2px solid #e0e6ed;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
            background-color: #f8fafc;
            color: var(--secondary);
        }
        
        input[type="number"]:focus,
        input[type="text"]:focus {
            outline: none;
            border-color: var(--primary);
            background-color: white;
            box-shadow: 0 0 0 4px rgba(52, 152, 219, 0.15);
            padding-left: 55px;
        }
        
        button[type="submit"] {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 18px 30px;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            letter-spacing: 0.5px;
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            position: relative;
            overflow: hidden;
            margin-top: 10px;
        }
        
        .delete-card button[type="submit"] {
            background: linear-gradient(to right, #e74c3c, #c0392b);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
        }
        
        button[type="submit"]:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(52, 152, 219, 0.4);
        }
        
        .delete-card button[type="submit"]:hover {
            box-shadow: 0 8px 20px rgba(231, 76, 60, 0.4);
        }
        
        button[type="submit"]:active {
            transform: translateY(0);
        }
        
        .hidden-input {
            display: none;
        }
        
        .quick-actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 50px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 15px 25px;
            border-radius: 10px;
            background: white;
            color: var(--secondary);
            text-decoration: none;
            font-weight: 600;
            box-shadow: var(--shadow);
            transition: all 0.3s;
            border: 2px solid transparent;
        }
        
        .action-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
            border-color: var(--primary);
        }
        
        .action-btn.view {
            color: var(--success);
        }
        
        .action-btn.edit {
            color: var(--warning);
        }
        
        .stats-bar {
            display: flex;
            justify-content: space-around;
            background: white;
            border-radius: var(--radius);
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .stat-item {
            text-align: center;
            flex: 1;
            min-width: 150px;
        }
        
        .stat-number {
            font-size: 36px;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            color: var(--gray);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .footer {
            text-align: center;
            margin-top: 60px;
            color: var(--gray);
            font-size: 14px;
            padding-top: 20px;
            border-top: 1px solid #e0e6ed;
        }
        
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 20px;
            border-radius: var(--radius);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            max-width: 350px;
            transform: translateX(400px);
            transition: transform 0.5s ease;
            border-left: 5px solid var(--primary);
            z-index: 1000;
        }
        
        .notification.show {
            transform: translateX(0);
        }
        
        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            
            h2 {
                font-size: 32px;
            }
            
            .stats-bar {
                flex-direction: column;
                align-items: center;
            }
            
            .stat-item {
                min-width: 100%;
            }
        }
        
        /* Animation for form submission */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .submitting {
            animation: pulse 1s infinite;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <div class="university-badge">ASTU - Adama Science and Technology University</div>
            <h2>Student Management System</h2>
            <p class="subtitle">Manage student records efficiently with our comprehensive CRUD system. Add new students or remove existing ones with ease.</p>
            
            <!-- Stats Bar -->
            <div class="stats-bar">
                <div class="stat-item">
                    <div class="stat-number" id="totalStudents">0</div>
                    <div class="stat-label">Total Students</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="departments">12</div>
                    <div class="stat-label">Departments</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="activeUsers">1</div>
                    <div class="stat-label">Active User</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number" id="todayOperations">0</div>
                    <div class="stat-label">Today's Operations</div>
                </div>
            </div>
        </div>
        
        <!-- Dashboard Cards -->
        <div class="dashboard-cards">
            <!-- CREATE FORM CARD -->
            <div class="card">
                <div class="card-icon">
                    <span>➕</span>
                </div>
                <h3>Add New Student</h3>
                <form action="studentservlet" method="POST" id="createForm">
                    <input type="hidden" name="action" value="create" class="hidden-input">
                    
                    <div class="form-group">
                        <label for="id">Student ID</label>
                        <div class="input-with-icon">
                            <div class="input-icon">#️⃣</div>
                            <input type="number" name="id" id="id" placeholder="Enter student ID" required min="1000">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <div class="input-with-icon">
                            <div class="input-icon">👤</div>
                            <input type="text" name="name" id="name" placeholder="Enter full name" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="dept">Department</label>
                        <div class="input-with-icon">
                            <div class="input-icon">🏛️</div>
                            <input type="text" name="dept" id="dept" placeholder="Enter department" required>
                        </div>
                    </div>
                    
                    <button type="submit" id="createBtn">Add Student</button>
                </form>
            </div>
            
            <!-- DELETE FORM CARD -->
            <div class="card delete-card">
                <div class="card-icon">
                    <span>🗑️</span>
                </div>
                <h3>Delete Student</h3>
                <form action="studentservlet" method="POST" id="deleteForm">
                    <input type="hidden" name="action" value="delete" class="hidden-input">
                    
                    <div class="form-group">
                        <label for="deleteId">Student ID</label>
                        <div class="input-with-icon">
                            <div class="input-icon">#️⃣</div>
                            <input type="number" name="id" id="deleteId" placeholder="Enter student ID to delete" required min="1000">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmDelete">
                            <input type="checkbox" id="confirmDelete" required>
                            I confirm I want to delete this student record
                        </label>
                    </div>
                    
                    <button type="submit" id="deleteBtn">Delete Student</button>
                </form>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions">
            <a href="#" class="action-btn view" onclick="showNotification('View functionality will be available soon!', 'info')">
                <span>👁️</span> View All Students
            </a>
            <a href="#" class="action-btn edit" onclick="showNotification('Edit functionality will be available soon!', 'warning')">
                <span>✏️</span> Edit Student
            </a>
            <a href="#" class="action-btn" onclick="showNotification('Report generation will be available soon!', 'info')">
                <span>📊</span> Generate Report
            </a>
            <a href="#" class="action-btn" onclick="showNotification('Search functionality will be available soon!', 'info')">
                <span>🔍</span> Search Student
            </a>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>ASTU Student Management System v2.0 • © 2023 Adama Science and Technology University</p>
            <p>For assistance, contact: support@astu.edu.et</p>
        </div>
        
        <!-- Notification -->
        <div class="notification" id="notification">
            <div id="notificationMessage"></div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize stats with random values
            document.getElementById('totalStudents').textContent = Math.floor(Math.random() * 500) + 100;
            document.getElementById('todayOperations').textContent = Math.floor(Math.random() * 10) + 1;
            
            // Form submission animations
            const createForm = document.getElementById('createForm');
            const deleteForm = document.getElementById('deleteForm');
            const createBtn = document.getElementById('createBtn');
            const deleteBtn = document.getElementById('deleteBtn');
            
            createForm.addEventListener('submit', function(e) {
                // Validate form before submission
                if (!this.checkValidity()) {
                    e.preventDefault();
                    showNotification('Please fill in all required fields correctly!', 'error');
                    return;
                }
                
                // Add submitting animation
                createBtn.classList.add('submitting');
                createBtn.innerHTML = 'Adding Student... <span class="spinner">⏳</span>';
                
                // Show success notification (in real app, this would be after server response)
                setTimeout(() => {
                    showNotification('Student added successfully!', 'success');
                }, 1000);
            });
            
            deleteForm.addEventListener('submit', function(e) {
                if (!this.checkValidity()) {
                    e.preventDefault();
                    showNotification('Please confirm deletion by checking the box!', 'error');
                    return;
                }
                
                // Add submitting animation
                deleteBtn.classList.add('submitting');
                deleteBtn.innerHTML = 'Deleting Student... <span class="spinner">⏳</span>';
                
                // Show warning notification
                showNotification('Warning: This action cannot be undone!', 'warning');
                
                // In a real app, you might want to confirm deletion
                const confirmed = confirm('Are you sure you want to delete this student record? This action cannot be undone.');
                if (!confirmed) {
                    e.preventDefault();
                    deleteBtn.classList.remove('submitting');
                    deleteBtn.innerHTML = 'Delete Student';
                    return;
                }
            });
            
            // Input validation and styling
            const inputs = document.querySelectorAll('input[type="number"], input[type="text"]');
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    if (this.checkValidity()) {
                        this.style.borderColor = '#27ae60';
                        this.style.backgroundColor = '#f9fff9';
                    } else {
                        this.style.borderColor = '#e74c3c';
                        this.style.backgroundColor = '#fff9f9';
                    }
                });
                
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'translateY(-2px)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'translateY(0)';
                });
            });
            
            // Auto-suggest for department field
            const deptInput = document.getElementById('dept');
            const departments = [
                'Computer Science', 'Electrical Engineering', 'Mechanical Engineering',
                'Civil Engineering', 'Chemical Engineering', 'Software Engineering',
                'Information Technology', 'Biomedical Engineering', 'Aeronautical Engineering',
                'Mathematics', 'Physics', 'Chemistry'
            ];
            
            let deptDatalist = document.createElement('datalist');
            deptDatalist.id = 'deptSuggestions';
            departments.forEach(dept => {
                let option = document.createElement('option');
                option.value = dept;
                deptDatalist.appendChild(option);
            });
            document.body.appendChild(deptDatalist);
            deptInput.setAttribute('list', 'deptSuggestions');
            
            // Notification system
            window.showNotification = function(message, type = 'info') {
                const notification = document.getElementById('notification');
                const notificationMessage = document.getElementById('notificationMessage');
                
                notificationMessage.innerHTML = message;
                notification.classList.add('show');
                
                // Style based on type
                notification.style.borderLeftColor = 
                    type === 'success' ? '#27ae60' : 
                    type === 'error' ? '#e74c3c' : 
                    type === 'warning' ? '#f39c12' : '#3498db';
                
                // Auto-hide after 5 seconds
                setTimeout(() => {
                    notification.classList.remove('show');
                }, 5000);
            };
            
            // Simulate loading stats
            setTimeout(() => {
                document.getElementById('totalStudents').style.transform = 'scale(1.2)';
                setTimeout(() => {
                    document.getElementById('totalStudents').style.transform = 'scale(1)';
                }, 300);
            }, 1000);
            
            // Add keyboard shortcuts
            document.addEventListener('keydown', function(e) {
                // Ctrl + Enter to submit create form
                if (e.ctrlKey && e.key === 'Enter' && 
                    (document.activeElement === document.getElementById('name') || 
                     document.activeElement === document.getElementById('dept'))) {
                    createForm.requestSubmit();
                }
                
                // Escape to clear forms
                if (e.key === 'Escape') {
                    createForm.reset();
                    deleteForm.reset();
                }
            });
        });
    </script>
</body>
</html>