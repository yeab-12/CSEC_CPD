package com.servlet; // Make sure this is here!

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Use your actual database name and password
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/university_db", "root", "password");
    }
}